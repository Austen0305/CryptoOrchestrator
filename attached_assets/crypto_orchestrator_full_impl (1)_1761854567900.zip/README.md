    # Crypto Bot Orchestrator - Full Implementation Scaffolding

This repository scaffolds an orchestrator and adapters for Hummingbot, Gekko, and OctoBot.

**Important**: The containers build process will attempt to clone the upstream open-source projects from GitHub at image build time. That means you need network access when you run `docker build` or `docker-compose up --build` on your machine.

Security notes:
- Do not put API keys in the repo. Use environment variables or Docker secrets.
- The adapters will start the actual bots inside their containers; monitor logs and test with paper trading before using real funds.

Sources / references used to craft the Dockerfiles and run commands:
- Hummingbot install: https://hummingbot.org/installation/
- Gekko repo: https://github.com/askmike/gekko
- OctoBot docs: https://www.octobot.cloud/

